export type PagerScrollEvent = {
    position: number;
    offset: number;
    eventName: string;
};
type Handlers = {
    onPageScroll: (event: PagerScrollEvent, context: unknown) => void;
};
export declare function usePagerScrollHandler(handlers: Handlers, dependencies?: unknown[]): import("react-native-reanimated").EventHandlerProcessed<PagerScrollEvent, never>;
export {};
//# sourceMappingURL=usePagerScrollHandler.d.ts.map