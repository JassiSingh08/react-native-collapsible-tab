import { Tab } from './Tab';
import { TabScrollView } from './ScrollView';
export { Container, type ContainerProps, type CollapsingTabsRef, type TabBarRenderProps, type TabChangeEvent, } from './Container';
export { Tab, type TabProps } from './Tab';
export { TabScrollView, type TabScrollViewProps } from './ScrollView';
export { TabFlatList, type TabFlatListProps } from './FlatList';
export { TabSectionList, type TabSectionListProps } from './SectionList';
export { DefaultTabBar, type DefaultTabBarProps } from './TabBar';
export { useActiveTabScrollY, useAnimatedTabIndex, useCollapseProgress, useCurrentTabScrollY, useFocusedTab, useHeaderMeasurements, useHeaderScrollY, useIsTabFocused, useTabIndex, } from './hooks';
export { useRestoreTabOffset, useTabContentStyle, useTabScrollLifecycle, } from './adapterUtils';
export { useRegisterTabList } from './hooks-internal';
export { useCollapsingTabsContext, useTabPageContext, type TabListHandle, } from './context';
/**
 * Compound namespace mirroring react-native-collapsible-tab-view's API:
 *
 *   <Tabs.Container renderHeader={...}>
 *     <Tabs.Tab name="posts" label="Posts">
 *       <Tabs.FlatList ... />
 *     </Tabs.Tab>
 *   </Tabs.Container>
 *
 * FlashList and LegendList adapters live in subpath exports so the packages
 * stay optional: `@scanner/react-native-collapsible-tabs/flash-list` and
 * `@scanner/react-native-collapsible-tabs/legend-list`.
 */
export declare const Tabs: {
    Container: import("react").ForwardRefExoticComponent<import("./Container").ContainerProps & import("react").RefAttributes<import("./Container").CollapsingTabsRef>>;
    Tab: typeof Tab;
    ScrollView: typeof TabScrollView;
    FlatList: <ItemT>(props: import("./FlatList").TabFlatListProps<ItemT> & {
        ref?: import("react").Ref<import("react-native").FlatList<ItemT>>;
    }) => import("react").ReactElement;
    SectionList: <ItemT, SectionT = import("react-native").DefaultSectionT>(props: import("./SectionList").TabSectionListProps<ItemT, SectionT> & {
        ref?: import("react").Ref<import("react-native").SectionList<ItemT, SectionT>>;
    }) => import("react").ReactElement;
};
//# sourceMappingURL=index.d.ts.map