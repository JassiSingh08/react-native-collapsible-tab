import { type StyleProp, type ViewStyle } from 'react-native';
import type { NativeScrollEvent, NativeSyntheticEvent } from 'react-native';
/**
 * Merges the container's layout requirements into a user-provided
 * contentContainerStyle: top padding so content starts below header + tab
 * bar, and (optionally) a minHeight so even short tabs can fully collapse
 * the header.
 */
export declare function useTabContentStyle(contentContainerStyle: StyleProp<ViewStyle> | undefined, { minHeight }?: {
    minHeight?: boolean;
}): ViewStyle;
type ScrollEvent = NativeSyntheticEvent<NativeScrollEvent>;
type UserScrollHandlers = {
    onScrollBeginDrag?: (e: ScrollEvent) => void;
    onScrollEndDrag?: (e: ScrollEvent) => void;
    onMomentumScrollEnd?: (e: ScrollEvent) => void;
};
/**
 * JS-thread scroll lifecycle handlers for adapters whose scroll offset is
 * tracked elsewhere (e.g. LegendList's sharedValues): cancel header
 * drag/snap animations when the user grabs the list, snap on rest.
 */
export declare function useTabScrollLifecycle(user: UserScrollHandlers): {
    onScrollBeginDrag: (e: ScrollEvent) => void;
    onScrollEndDrag: (e: ScrollEvent) => void;
    onMomentumScrollEnd: (e: ScrollEvent) => void;
};
/**
 * Restores a tab's saved scroll offset when its list mounts. Needed for lazy
 * tabs: syncTab may have written this tab's offset (so the header/content
 * geometry is gapless on arrival) while the list didn't exist yet.
 */
export declare function useRestoreTabOffset(scrollToOffset: (offset: number) => void): void;
export {};
//# sourceMappingURL=adapterUtils.d.ts.map