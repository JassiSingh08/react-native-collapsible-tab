import { type ReactElement, type Ref } from 'react';
import type { FlatList, FlatListProps } from 'react-native';
export type TabFlatListProps<ItemT> = Omit<FlatListProps<ItemT>, 'onScroll'>;
/** FlatList wired into the collapsing-tabs container. */
export declare const TabFlatList: <ItemT>(props: TabFlatListProps<ItemT> & {
    ref?: Ref<FlatList<ItemT>>;
}) => ReactElement;
//# sourceMappingURL=FlatList.d.ts.map