export { TabLegendList, type TabLegendListProps } from './LegendList';
//# sourceMappingURL=legend-list.d.ts.map