import { type ReactElement, type Ref } from 'react';
import type { FlashListProps, FlashListRef } from '@shopify/flash-list';
export type TabFlashListProps<ItemT> = Omit<FlashListProps<ItemT>, 'renderScrollComponent'>;
/**
 * FlashList v2 wired into the collapsing-tabs container.
 * Requires @shopify/flash-list >= 2 (New Architecture only).
 */
export declare const TabFlashList: <ItemT>(props: TabFlashListProps<ItemT> & {
    ref?: Ref<FlashListRef<ItemT>>;
}) => ReactElement;
//# sourceMappingURL=FlashList.d.ts.map