import { type ReactElement, type Ref } from 'react';
import { SectionList } from 'react-native';
import type { DefaultSectionT, SectionListProps } from 'react-native';
export type TabSectionListProps<ItemT, SectionT = DefaultSectionT> = Omit<SectionListProps<ItemT, SectionT>, 'onScroll'>;
/** SectionList wired into the collapsing-tabs container. */
export declare const TabSectionList: <ItemT, SectionT = DefaultSectionT>(props: TabSectionListProps<ItemT, SectionT> & {
    ref?: Ref<SectionList<ItemT, SectionT>>;
}) => ReactElement;
//# sourceMappingURL=SectionList.d.ts.map