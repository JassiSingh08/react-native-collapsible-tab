import { type ReactNode } from 'react';
type TabPageProps = {
    index: number;
    name: string;
    /** False while a lazy tab hasn't been focused yet — renders the placeholder instead. */
    mount: boolean;
    placeholder?: ReactNode;
    children: ReactNode;
};
/**
 * Per-tab wrapper. Owns the animated ref to the tab's scroll view so the
 * header pan gesture (which writes `dragTarget`) can drive this list via
 * scrollTo entirely on the UI thread.
 */
export declare function TabPage({ index, name, mount, placeholder, children, }: TabPageProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=TabPage.d.ts.map