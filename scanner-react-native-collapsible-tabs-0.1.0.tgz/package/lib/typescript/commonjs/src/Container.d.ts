import React, { type ReactNode } from 'react';
import { type StyleProp, type ViewStyle } from 'react-native';
import PagerView from 'react-native-pager-view';
import { type SharedValue } from 'react-native-reanimated';
export type TabBarRenderProps = {
    tabNames: string[];
    /** Display labels keyed by tab name (falls back to the name itself). */
    tabLabels: Record<string, string>;
    focusedTab: SharedValue<string>;
    /** Continuous pager position (fractional during swipes). */
    indexDecimal: SharedValue<number>;
    /** React-state mirror of the focused tab index. */
    activeIndex: number;
    onTabPress: (name: string) => void;
};
export type TabChangeEvent = {
    prevIndex: number;
    index: number;
    prevTabName: string;
    tabName: string;
};
export type CollapsingTabsRef = {
    /** Switch to a tab by name. */
    jumpToTab: (name: string, animated?: boolean) => void;
    /** Switch to a tab by index. */
    setIndex: (index: number, animated?: boolean) => void;
    getFocusedTab: () => string;
    getCurrentIndex: () => number;
    /** Scroll the focused tab to the top (expands the header). */
    scrollToTop: (animated?: boolean) => void;
    /** Reset every tab's scroll position and expand the header. */
    scrollAllToTop: () => void;
};
export type ContainerProps = {
    /** Omit for a plain pinned tab bar with no collapsible header. */
    renderHeader?: () => ReactNode;
    renderTabBar?: (props: TabBarRenderProps) => ReactNode;
    /** Header px that stays visible when fully collapsed (e.g. safe-area top). */
    minHeaderHeight?: number;
    /**
     * Solid backing behind header + tab bar. Since collapse is decoupled from
     * per-tab offsets, scrolled content can legitimately sit underneath an
     * expanded header — translucent headers would show it bleeding through.
     */
    headerBackgroundColor?: string;
    /** Extra styles for the animated header+tab-bar wrapper. */
    headerContainerStyle?: StyleProp<ViewStyle>;
    containerStyle?: StyleProp<ViewStyle>;
    initialTabName?: string;
    /**
     * Mount tab content only when the tab is first focused (or its neighbor is
     * being dragged in). `false` mounts everything up front — and means it.
     */
    lazy?: boolean;
    /** Rendered in place of a lazy tab's content until it mounts. */
    renderLazyPlaceholder?: (props: {
        name: string;
        index: number;
    }) => ReactNode;
    /** Any upward scroll reveals the header immediately (Twitter-style). */
    revealHeaderOnScroll?: boolean;
    /**
     * When set (0..1), a header released mid-collapse animates fully open or
     * closed. E.g. 0.5 snaps to whichever edge is closer. Omit to disable.
     */
    snapThreshold?: number | null;
    onIndexChange?: (index: number) => void;
    /** Fires once per settled tab switch — never for intermediate pages. */
    onTabChange?: (event: TabChangeEvent) => void;
    /** Escape hatch passed straight to the underlying PagerView. */
    pagerProps?: Omit<React.ComponentProps<typeof PagerView>, 'children' | 'initialPage' | 'onPageSelected' | 'onPageScroll' | 'onPageScrollStateChanged'>;
    children: ReactNode;
};
export declare const Container: React.ForwardRefExoticComponent<ContainerProps & React.RefAttributes<CollapsingTabsRef>>;
//# sourceMappingURL=Container.d.ts.map