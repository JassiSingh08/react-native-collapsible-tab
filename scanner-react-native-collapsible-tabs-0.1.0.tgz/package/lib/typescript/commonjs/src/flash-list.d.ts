export { TabFlashList, type TabFlashListProps } from './FlashList';
//# sourceMappingURL=flash-list.d.ts.map