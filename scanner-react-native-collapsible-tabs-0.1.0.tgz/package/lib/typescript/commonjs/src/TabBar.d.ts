import React from 'react';
import { type StyleProp, type TextStyle, type ViewStyle } from 'react-native';
import { type SharedValue } from 'react-native-reanimated';
export type DefaultTabBarProps = {
    tabNames: string[];
    /** Display labels keyed by tab name; falls back to the name. */
    tabLabels?: Record<string, string>;
    focusedTab: SharedValue<string>;
    indexDecimal: SharedValue<number>;
    onTabPress: (name: string) => void;
    /** React-state mirror of the active tab, for label styling. */
    activeIndex: number;
    /**
     * Scrollable bar (tabs size to their label, bar scrolls horizontally) vs
     * fixed bar (tabs share the width equally). Defaults to scrollable.
     */
    scrollable?: boolean;
    backgroundColor?: string;
    activeColor?: string;
    inactiveColor?: string;
    indicatorColor?: string;
    style?: StyleProp<ViewStyle>;
    tabStyle?: StyleProp<ViewStyle>;
    labelStyle?: StyleProp<TextStyle>;
    indicatorStyle?: StyleProp<ViewStyle>;
    renderLabel?: (props: {
        name: string;
        label: string;
        index: number;
        focused: boolean;
        color: string;
    }) => React.ReactNode;
};
/**
 * Simple tab bar with a swipe-tracking underline indicator. Fully optional —
 * pass `renderTabBar` to the container for a custom one.
 */
export declare function DefaultTabBar({ tabNames, tabLabels, indexDecimal, onTabPress, activeIndex, scrollable, backgroundColor, activeColor, inactiveColor, indicatorColor, style, tabStyle, labelStyle, indicatorStyle: userIndicatorStyle, renderLabel, }: DefaultTabBarProps): React.JSX.Element;
//# sourceMappingURL=TabBar.d.ts.map