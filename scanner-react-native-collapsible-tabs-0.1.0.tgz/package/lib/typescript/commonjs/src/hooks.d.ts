import { type SharedValue } from 'react-native-reanimated';
/**
 * Header collapse in px (0 = fully expanded .. collapseRange), as a read-only
 * derived value. Drives header animations (parallax, fade, ...). Note it
 * tracks the HEADER, not any tab's raw offset: since collapse is decoupled
 * from per-tab offsets, a deep-scrolled tab can be active while the header
 * is expanded.
 */
export declare function useHeaderScrollY(): SharedValue<number>;
/** Header collapse normalized to 0 (expanded) .. 1 (collapsed). */
export declare function useCollapseProgress(): SharedValue<number>;
/**
 * Compatible with react-native-collapsible-tab-view's hook of the same name:
 * `top` is the header's animated translateY (0 .. -collapseRange), `height`
 * its measured height.
 */
export declare function useHeaderMeasurements(): {
    top: SharedValue<number>;
    height: number;
};
/**
 * Raw scroll offset of the tab this hook is rendered inside.
 * Mirrors react-native-collapsible-tab-view's useCurrentTabScrollY.
 */
export declare function useCurrentTabScrollY(): SharedValue<number>;
/**
 * Raw scroll offset of whichever tab is focused — usable outside tab
 * content (e.g. in the header or tab bar).
 */
export declare function useActiveTabScrollY(): SharedValue<number>;
/** Name of the focused tab as a shared value (updates on tab settle). */
export declare function useFocusedTab(): SharedValue<string>;
/** Continuous pager position (fractional during swipes) as a shared value. */
export declare function useAnimatedTabIndex(): SharedValue<number>;
/** JS-state focus check for the named tab (re-renders on tab switch). */
export declare function useIsTabFocused(name: string): boolean;
/** JS-state focused tab index (re-renders on tab switch). */
export declare function useTabIndex(): number;
//# sourceMappingURL=hooks.d.ts.map