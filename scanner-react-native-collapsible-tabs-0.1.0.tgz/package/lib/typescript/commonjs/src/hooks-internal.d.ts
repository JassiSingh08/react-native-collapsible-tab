import { type TabListHandle } from './context';
/** Registers a tab list's imperative handle for the container's offset syncs. */
export declare function useRegisterTabList(handle: TabListHandle): void;
//# sourceMappingURL=hooks-internal.d.ts.map