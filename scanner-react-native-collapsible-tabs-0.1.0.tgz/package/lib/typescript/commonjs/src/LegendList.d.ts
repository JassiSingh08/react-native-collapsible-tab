import { type ReactElement, type Ref } from 'react';
import type { LegendListRef } from '@legendapp/list/react-native';
import type { AnimatedLegendListProps } from '@legendapp/list/reanimated';
export type TabLegendListProps<ItemT> = Omit<AnimatedLegendListProps<ItemT>, 'refScrollView' | 'sharedValues'>;
/**
 * LegendList wired into the collapsing-tabs container.
 * Requires @legendapp/list (optional peer dependency).
 */
export declare const TabLegendList: <ItemT>(props: TabLegendListProps<ItemT> & {
    ref?: Ref<LegendListRef>;
}) => ReactElement;
//# sourceMappingURL=LegendList.d.ts.map