import { type ComponentProps } from 'react';
import Animated from 'react-native-reanimated';
export type TabScrollViewProps = Omit<ComponentProps<typeof Animated.ScrollView>, 'onScroll'>;
/** ScrollView wired into the collapsing-tabs container. */
export declare function TabScrollView({ children, contentContainerStyle, scrollIndicatorInsets, ...rest }: TabScrollViewProps): import("react").JSX.Element;
//# sourceMappingURL=ScrollView.d.ts.map